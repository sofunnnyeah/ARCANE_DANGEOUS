// ================= УВЕДОМЛЕНИЯ =================
function showToast(title, text, type = 'info') {
  const container = document.getElementById('toasts');
  if (!container) return;
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<div class="toast-title">${title}</div><div class="toast-text">${text}</div>`;
  container.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 3500);
}

// ================= НАВИГАЦИЯ =================
function openScreen(id) { document.getElementById(id)?.classList.add('active'); }
function closeScreen(id) { document.getElementById(id)?.classList.remove('active'); }
document.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => closeScreen(btn.dataset.close)));
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('pane-' + btn.dataset.tab)?.classList.add('active');
  });
});

// ================= ПЕРЕВОДЫ =================
const translations = {
  ru: {
    nickname: "Твой никнейм", avatar: "Выбери аватар", enter_game: "Войти в подземелье",
    subtitle: "ПРОКЛЯТИЕ ДРЕВНЕЙ МАГИИ", play: "ИГРАТЬ", music: "МУЗЫКА", settings: "НАСТРОЙКИ", exit: "ВЫЙТИ",
    level: "Уровень", tab_video: "Видео", tab_audio: "Звук", tab_language: "Язык",
    screen: "Экран", fullscreen: "Полноэкранный режим", volume: "Громкость",
    music_toggle: "Включить музыку", master_vol: "Общая громкость", music_vol: "Музыка",
    localization: "Локализация", interface_lang: "Язык интерфейса", close: "Закрыть",
    confirm: "Подтверждение", confirm_text: "Вы уверены?", cancel: "Отмена", yes: "Да",
    upload_music: "Загрузить свою музыку", play_random: "🎲 Включить случайный трек",
    friends: "ДРУЗЬЯ", lobby: "ЛОББИ"
  },
  en: {
    nickname: "Your nickname", avatar: "Choose avatar", enter_game: "Enter the dungeon",
    subtitle: "CURSE OF ANCIENT MAGIC", play: "PLAY", music: "MUSIC", settings: "SETTINGS", exit: "EXIT",
    level: "Level", tab_video: "Video", tab_audio: "Audio", tab_language: "Language",
    screen: "Screen", fullscreen: "Fullscreen mode", volume: "Volume",
    music_toggle: "Enable music", master_vol: "Master volume", music_vol: "Music",
    localization: "Localization", interface_lang: "Interface language", close: "Close",
    confirm: "Confirmation", confirm_text: "Are you sure?", cancel: "Cancel", yes: "Yes",
    upload_music: "Upload your music", play_random: "🎲 Play random track",
    friends: "FRIENDS", lobby: "LOBBY"
  },
  ua: {
    nickname: "Твій нікнейм", avatar: "Обери аватар", enter_game: "Увійти в підземелля",
    subtitle: "ПРОКЛЯТТЯ ДАВНЬОЇ МАГІЇ", play: "ГРАТИ", music: "МУЗИКА", settings: "НАЛАШТУВАННЯ", exit: "ВИЙТИ",
    level: "Рівень", tab_video: "Відео", tab_audio: "Звук", tab_language: "Мова",
    screen: "Екран", fullscreen: "Повноекранний режим", volume: "Гучність",
    music_toggle: "Увімкнути музику", master_vol: "Загальна гучність", music_vol: "Музика",
    localization: "Локалізація", interface_lang: "Мова інтерфейсу", close: "Закрити",
    confirm: "Підтвердження", confirm_text: "Ви впевнені?", cancel: "Скасувати", yes: "Так",
    upload_music: "Завантажити свою музику", play_random: "🎲 Увімкнути випадковий трек",
    friends: "ДРУЗІ", lobby: "ЛОБІ"
  }
};

let currentLang = 'ru';
function applyLanguage(lang) {
  currentLang = lang;
  document.querySelectorAll('[data-lang]').forEach(el => {
    const key = el.dataset.lang;
    if (translations[lang][key]) el.innerText = translations[lang][key];
  });
}

// ================= КЛЮЧИ И СОСТОЯНИЕ =================
const PLAYER_KEY = 'arcane_player_v8';
const SETTINGS_KEY = 'arcane_settings_v8';
let player = JSON.parse(localStorage.getItem(PLAYER_KEY) || 'null');
let selectedAvatar = '🧙‍♂️';

// ================= ИНИЦИАЛИЗАЦИЯ =================
document.addEventListener('DOMContentLoaded', () => {
  if (player && player.nickname) {
    closeScreen('screen-onboarding');
    openScreen('screen-main');
    updateProfileHeader();
  } else {
    openScreen('screen-onboarding');
  }
  loadSettings();
  loadMusicList();
});

// ================= ОНБОРДИНГ (Проверка на уникальность) =================
document.querySelectorAll('.avatar-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.avatar-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    selectedAvatar = btn.dataset.avatar;
  });
});
setTimeout(() => document.querySelector('.avatar-btn')?.classList.add('selected'), 100);

document.getElementById('btn-onboarding-done').addEventListener('click', () => {
  const input = document.getElementById('input-nickname');
  const error = document.getElementById('nickname-error');
  const nickname = input.value.trim();
  
  // ВАЛИДАЦИЯ
  if (nickname.length < 3 || nickname.length > 15) {
    error.innerText = 'Никнейм от 3 до 15 символов';
    error.style.display = 'block';
    return;
  }
  
  // ПРОВЕРКА НА УНИКАЛЬНОСТЬ (сохраняем всех игроков, которые заходили)
  let registeredPlayers = JSON.parse(localStorage.getItem('arcane_all_nicknames') || '[]');
  if (registeredPlayers.includes(nickname.toLowerCase())) {
    error.innerText = 'Этот никнейм уже занят';
    error.style.display = 'block';
    return;
  }
  
  // Регистрируем ник
  registeredPlayers.push(nickname.toLowerCase());
  localStorage.setItem('arcane_all_nicknames', JSON.stringify(registeredPlayers));
  
  player = { nickname, avatar: selectedAvatar, level: 1 };
  localStorage.setItem(PLAYER_KEY, JSON.stringify(player));
  
  closeScreen('screen-onboarding');
  openScreen('screen-main');
  updateProfileHeader();
  showToast('Добро пожаловать', `Привет, ${nickname}!`, 'success');
});

function updateProfileHeader() {
  if (!player) return;
  document.getElementById('profile-avatar').innerText = player.avatar;
  document.getElementById('profile-name').innerText = player.nickname;
}

// ================= МУЗЫКА =================
const playlistAudio = document.getElementById('playlist-audio');
let musicFiles = ['1.mp3', '2.mp3'];
let currentTrackIndex = -1;
let musicEnabled = false;

function loadMusicList() {
  musicFiles = ['1.mp3', '2.mp3']; // <-- ВПИСЫВАЙ СВОИ ФАЙЛЫ
  renderMusicList();
}

function renderMusicList() {
  const list = document.getElementById('music-list');
  if (!list) return;
  list.innerHTML = musicFiles.map((file, i) => `
    <div class="music-item" style="padding: 10px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
      <span>${i + 1}. ${file}</span>
      <button class="btn" style="height: 30px; padding: 0 10px; font-size: 12px;" onclick="playSpecificTrack('${file}')">▶️</button>
    </div>
  `).join('');
}

window.playSpecificTrack = function(filename) {
  if (!musicEnabled) {
    document.getElementById('toggle-music').checked = true;
    musicEnabled = true;
  }
  playlistAudio.src = 'music/' + encodeURIComponent(filename);
  playlistAudio.volume = (+document.getElementById('vol-master').value / 100) * (+document.getElementById('vol-music').value / 100);
  playlistAudio.play().catch(() => showToast('Ошибка', 'Файл не найден', 'error'));
};

function playRandomTrack() {
  if (musicFiles.length === 0) return;
  let index;
  do { index = Math.floor(Math.random() * musicFiles.length); } while (musicFiles.length > 1 && index === currentTrackIndex);
  currentTrackIndex = index;
  window.playSpecificTrack(musicFiles[index]);
}

document.getElementById('btn-play-random').addEventListener('click', () => {
  if (!musicEnabled) { document.getElementById('toggle-music').checked = true; musicEnabled = true; }
  playRandomTrack();
});

playlistAudio.addEventListener('ended', () => { if (musicEnabled) playRandomTrack(); });

// ================= ЛОББИ И P2P =================
let peer = null;
let conn = null;

document.getElementById('btn-play').addEventListener('click', () => {
  openScreen('screen-lobby');
});

document.getElementById('btn-solo').addEventListener('click', () => {
  closeScreen('screen-lobby');
  startGame(); // Запускаем игру без сети
});

// Создание комнаты
document.getElementById('btn-create-room').addEventListener('click', () => {
  // Генерируем случайный код из 5 символов
  const roomCode = 'ARC-' + Math.floor(1000 + Math.random() * 9000);
  
  // Инициализируем PeerJS (сервер PeerJS бесплатный)
  peer = new Peer(roomCode);
  
  peer.on('open', (id) => {
    document.getElementById('room-status').style.display = 'block';
    document.getElementById('my-room-code').innerText = id;
    showToast('Лобби', 'Комната создана. Ждите друга.', 'success');
  });

  peer.on('connection', (connection) => {
    conn = connection;
    document.getElementById('room-players').innerText = 'Игрок подключился!';
    showToast('Лобби', 'Игрок подключился! Начинаем...', 'success');
    setTimeout(() => {
      closeScreen('screen-lobby');
      startGame(); // Запуск игры в мультиплеере
    }, 1000);
  });

  peer.on('error', (err) => {
    showToast('Ошибка', 'Не удалось создать комнату', 'error');
    console.error(err);
  });
});

// Подключение по коду
document.getElementById('btn-join-room').addEventListener('click', () => {
  const code = document.getElementById('input-room-code').value.trim();
  if (!code) return showToast('Ошибка', 'Введите код', 'error');

  peer = new Peer(); // Создаём анонимного пира
  peer.on('open', () => {
    conn = peer.connect(code);
    conn.on('open', () => {
      showToast('Лобби', 'Подключено!', 'success');
      closeScreen('screen-lobby');
      startGame(); // Запускаем игру
    });
    conn.on('error', () => {
      showToast('Ошибка', 'Комната не найдена', 'error');
    });
  });
});

// ================= ИГРА (CANVAS) =================
const canvas = document.getElementById('game-canvas');
let ctx = null;
let playerX = 400, playerY = 300;
let isGameRunning = false;

function startGame() {
  openScreen('screen-game');
  ctx = canvas.getContext('2d');
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);
  
  isGameRunning = true;
  requestAnimationFrame(gameLoop);
}

function resizeCanvas() {
  if (!canvas) return;
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}

function gameLoop() {
  if (!isGameRunning) return;

  // Очистка
  ctx.fillStyle = '#0a0c14';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Сетка пола
  ctx.strokeStyle = 'rgba(49, 55, 84, 0.3)';
  ctx.lineWidth = 1;
  for (let x = 0; x < canvas.width; x += 50) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke(); }
  for (let y = 0; y < canvas.height; y += 50) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke(); }

  // Рисуем персонажа (Мага)
  drawMage(ctx, canvas.width / 2, canvas.height / 2, player.avatar);

  requestAnimationFrame(gameLoop);
}

// Функция отрисовки мага (вместо круга)
function drawMage(ctx, x, y, emoji) {
  // Свечение
  const gradient = ctx.createRadialGradient(x, y, 5, x, y, 50);
  gradient.addColorStop(0, 'rgba(135, 101, 216, 0.5)');
  gradient.addColorStop(1, 'rgba(135, 101, 216, 0)');
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(x, y, 50, 0, Math.PI * 2);
  ctx.fill();

  // Тень
  ctx.fillStyle = 'rgba(0,0,0,0.5)';
  ctx.beginPath();
  ctx.ellipse(x, y + 20, 25, 10, 0, 0, Math.PI * 2);
  ctx.fill();

  // Эмодзи персонажа
  ctx.font = '60px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(emoji || '🧙‍♂️', x, y);
}

// Выход из игры
document.getElementById('btn-exit-game').addEventListener('click', () => {
  isGameRunning = false;
  closeScreen('screen-game');
  openScreen('screen-lobby');
  if (conn) conn.close();
  if (peer) peer.destroy();
});

// ================= ОСТАЛЬНЫЕ КНОПКИ =================
document.getElementById('btn-friends').addEventListener('click', () => openScreen('screen-friends'));
document.getElementById('btn-music').addEventListener('click', () => openScreen('screen-music'));
document.getElementById('btn-settings').addEventListener('click', () => openScreen('screen-settings'));

// Выход
document.getElementById('btn-exit').addEventListener('click', () => {
  showConfirm('Выйти?', 'Вы уверены?', () => { playlistAudio.pause(); showToast('Игра', 'До встречи!', 'info'); });
});

// Закрытие окон по крестику и сохранение настроек
document.getElementById('select-language').addEventListener('change', (e) => { applyLanguage(e.target.value); saveSettings(); });
document.getElementById('toggle-fullscreen').addEventListener('change', (e) => {
  if (e.target.checked) document.documentElement.requestFullscreen?.();
  else if (document.exitFullscreen) document.exitFullscreen();
  saveSettings();
});
document.getElementById('toggle-music').addEventListener('change', (e) => {
  musicEnabled = e.target.checked;
  if (musicEnabled) playRandomTrack(); else playlistAudio.pause();
  saveSettings();
});
document.getElementById('vol-master').addEventListener('input', () => { updateMusicVolume(); saveSettings(); });
document.getElementById('vol-music').addEventListener('input', () => { updateMusicVolume(); saveSettings(); });

function updateMusicVolume() {
  if (!playlistAudio.paused) {
    const vol = (+document.getElementById('vol-master').value / 100) * (+document.getElementById('vol-music').value / 100);
    playlistAudio.volume = Math.min(1, Math.max(0, vol));
  }
}

function saveSettings() {
  const data = {
    fullscreen: document.getElementById('toggle-fullscreen').checked,
    musicEnabled: document.getElementById('toggle-music').checked,
    volMaster: document.getElementById('vol-master').value,
    volMusic: document.getElementById('vol-music').value,
    language: document.getElementById('select-language').value
  };
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(data));
}

function loadSettings() {
  const saved = localStorage.getItem(SETTINGS_KEY);
  if (!saved) return applyLanguage('ru');
  try {
    const data = JSON.parse(saved);
    document.getElementById('toggle-fullscreen').checked = data.fullscreen || false;
    document.getElementById('toggle-music').checked = data.musicEnabled || false;
    musicEnabled = data.musicEnabled || false;
    document.getElementById('vol-master').value = data.volMaster || 80;
    document.getElementById('vol-music').value = data.volMusic || 50;
    document.getElementById('select-language').value = data.language || 'ru';
    applyLanguage(data.language || 'ru');
  } catch(e) {}
}

// Подтверждение
let confirmCallback = null;
function showConfirm(title, text, cb) {
  document.getElementById('confirm-title').innerText = title;
  document.getElementById('confirm-text').innerText = text;
  confirmCallback = cb;
  openScreen('screen-confirm');
}
document.getElementById('confirm-cancel').addEventListener('click', () => { closeScreen('screen-confirm'); confirmCallback = null; });
document.getElementById('confirm-ok').addEventListener('click', () => { if (confirmCallback) confirmCallback(); closeScreen('screen-confirm'); confirmCallback = null; });