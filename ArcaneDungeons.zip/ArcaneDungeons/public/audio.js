/**
 * ARCANE DUNGEONS — AUDIO ENGINE
 * Управляет музыкой и SFX. Делает кроссфейд, плавную громкость.
 */

class AudioEngine {
  constructor() {
    this.tracks = {};
    this.sfx = {};
    this.currentMusic = null;
    this.masterGain = 1;
    this.musicGain = 0.5;
    this.sfxGain = 0.9;
    this.initialized = false;
    this.muted = false;
    this.prevGain = 0.5;
  }

  init(tracks = {}, sfx = {}) {
    // Загружаем музыку
    for (const name in tracks) {
      const audio = new Audio();
      audio.src = tracks[name];
      audio.loop = true;
      audio.preload = 'auto';
      audio.volume = 0;
      audio.addEventListener('error', () => {
        console.warn(`⚠️ Трек "${name}" не загружен (${tracks[name]})`);
      });
      this.tracks[name] = audio;
    }
    
    // Загружаем SFX
    for (const name in sfx) {
      const audio = new Audio();
      audio.src = sfx[name];
      audio.preload = 'auto';
      audio.addEventListener('error', () => {
        console.warn(`⚠️ SFX "${name}" не загружен`);
      });
      this.sfx[name] = audio;
    }
    
    this.initialized = true;
    console.log(`🎵 AudioEngine готов: ${Object.keys(this.tracks).length} треков, ${Object.keys(this.sfx).length} эффектов`);
    
    // Приглушение при потере фокуса
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.muteAll(true);
      } else {
        this.muteAll(false);
      }
    });
  }

  playMusic(name, volume = null) {
    if (!this.initialized || !this.tracks[name]) return;
    
    const targetVol = volume !== null 
      ? volume * this.masterGain * this.musicGain
      : this.masterGain * this.musicGain;
    
    if (this.currentMusic === name && !this.tracks[name].paused) return;
    
    // Кроссфейд: старый плавно уходит
    if (this.currentMusic && this.tracks[this.currentMusic]) {
      this.fadeOut(this.tracks[this.currentMusic], 800);
    }
    
    const track = this.tracks[name];
    track.volume = 0;
    track.currentTime = 0;
    
    const promise = track.play();
    if (promise !== undefined) {
      promise.catch(() => {
        // Автовоспроизведение заблокировано — ждём клика
        this.pendingPlay = { name, volume };
        document.addEventListener('click', () => {
          if (this.pendingPlay) {
            const { name, volume } = this.pendingPlay;
            this.pendingPlay = null;
            this.playMusic(name, volume);
          }
        }, { once: true });
      });
    }
    
    this.currentMusic = name;
    this.fadeIn(track, targetVol, 1000);
  }

  stopMusic(immediate = false) {
    if (this.currentMusic && this.tracks[this.currentMusic]) {
      const track = this.tracks[this.currentMusic];
      if (immediate) {
        track.pause();
        track.currentTime = 0;
      } else {
        this.fadeOut(track, 800, () => {
          track.pause();
          track.currentTime = 0;
        });
      }
    }
    this.currentMusic = null;
  }

  pauseMusic() {
    if (this.currentMusic && this.tracks[this.currentMusic]) {
      this.tracks[this.currentMusic].pause();
    }
  }

  resumeMusic() {
    if (this.currentMusic && this.tracks[this.currentMusic]) {
      this.tracks[this.currentMusic].play().catch(() => {});
    }
  }

  playSfx(name, volume = null) {
    if (!this.initialized || !this.sfx[name]) return;
    
    const targetVol = volume !== null 
      ? volume * this.masterGain * this.sfxGain
      : this.masterGain * this.sfxGain;
    
    const clone = this.sfx[name].cloneNode();
    clone.volume = Math.min(1, Math.max(0, targetVol));
    clone.play().catch(() => {});
    clone.addEventListener('ended', () => clone.remove());
  }

  setMusicVolume(percent) {
    this.musicGain = percent / 100;
    if (this.currentMusic && this.tracks[this.currentMusic]) {
      const track = this.tracks[this.currentMusic];
      this.fadeTo(track, this.masterGain * this.musicGain, 200);
    }
  }

  setSfxVolume(percent) {
    this.sfxGain = percent / 100;
  }

  setMasterVolume(percent) {
    this.masterGain = percent / 100;
    if (this.currentMusic && this.tracks[this.currentMusic]) {
      const track = this.tracks[this.currentMusic];
      this.fadeTo(track, this.masterGain * this.musicGain, 200);
    }
  }

  muteAll(muted) {
    if (muted) {
      this.prevGain = this.musicGain;
      this.musicGain = 0;
    } else {
      this.musicGain = this.prevGain;
    }
    
    if (this.currentMusic && this.tracks[this.currentMusic]) {
      const track = this.tracks[this.currentMusic];
      track.volume = muted ? 0 : this.masterGain * this.musicGain;
    }
  }

  fadeIn(track, targetVol, duration = 1000) {
    const startVol = track.volume;
    const startTime = performance.now();
    
    const step = (now) => {
      const progress = Math.min(1, (now - startTime) / duration);
      track.volume = Math.min(1, startVol + (targetVol - startVol) * progress);
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  fadeOut(track, duration = 800, onComplete = null) {
    const startVol = track.volume;
    const startTime = performance.now();
    
    const step = (now) => {
      const progress = Math.min(1, (now - startTime) / duration);
      track.volume = Math.max(0, startVol * (1 - progress));
      if (progress < 1) {
        requestAnimationFrame(step);
      } else if (onComplete) {
        onComplete();
      }
    };
    requestAnimationFrame(step);
  }

  fadeTo(track, targetVol, duration = 200) {
    const startVol = track.volume;
    const startTime = performance.now();
    
    const step = (now) => {
      const progress = Math.min(1, (now - startTime) / duration);
      track.volume = Math.min(1, Math.max(0, startVol + (targetVol - startVol) * progress));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  stopAll() {
    this.stopMusic(true);
    for (const name in this.sfx) {
      this.sfx[name].pause();
      this.sfx[name].currentTime = 0;
    }
  }
}

// ================= ГЛОБАЛЬНЫЙ ЭКЗЕМПЛЯР =================
const audio = new AudioEngine();

// Инициализация
audio.init(
  {
    menu: 'music/menu.mp3',
    game: 'music/bg.mp3'
  },
  {
    click: 'music/click.mp3',
    hover: 'music/hover.mp3',
    open: 'music/open.mp3',
    close: 'music/close.mp3',
    error: 'music/error.mp3',
    success: 'music/success.mp3'
  }
);

// Экспорт в window для быстрого вызова
window.arcaneAudio = audio;